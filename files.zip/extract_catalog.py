"""
Generic parts-catalogue extractor. Works on ANY illustrated parts catalogue
PDF that has a tabular Bill of Materials -- doesn't assume specific column
names, page numbers, or part-number formats for THIS gearbox. Finds the BOM
table by looking for a header row containing recognizable column concepts
(part number / description / quantity), then normalizes whatever headers it
actually finds to a common schema.
"""
import pdfplumber
import re
import json
import sys

# header concepts we're looking for -> normalized field name
HEADER_ALIASES = {
    "part_no":     ["part no", "part number", "pn", "part#", "oem pn", "item no"],
    "description": ["description", "desc", "name"],
    "sub_asm":     ["sub-asm", "sub asm", "subassembly", "assembly", "group"],
    "qty":         ["qty", "qty / assy", "quantity", "qty/assy"],
    "material":    ["material", "matl"],
    "item":        ["item", "ite\nm", "item no", "no."],
}

# generic pattern for an alphanumeric part-number token, e.g. GBX-HXB-122,
# ABC-1234-B, XY99-001 -- hyphen-separated alnum blocks, at least 2 segments
PN_PATTERN = re.compile(r"\b[A-Z]{2,6}-[A-Z0-9]{1,8}-[A-Z0-9]{1,6}(?:-[A-Z0-9]{1,4})?\b")

def normalize_header(cell):
    if not cell:
        return None
    c = cell.strip().lower().replace("\n", " ")
    for norm, aliases in HEADER_ALIASES.items():
        if any(a in c for a in aliases):
            return norm
    return None

def looks_like_bom_header(row):
    normed = [normalize_header(c) for c in row]
    return "part_no" in normed and ("description" in normed or "qty" in normed)

def extract_bom(pdf_path):
    rows_out = []
    header_map = None
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            for table in page.extract_tables():
                if not table:
                    continue
                for row in table:
                    if looks_like_bom_header(row):
                        header_map = {i: normalize_header(c) for i, c in enumerate(row)}
                        continue
                    if header_map is None:
                        continue
                    # must contain something matching a part-number pattern to count as a data row
                    row_text = " ".join(c or "" for c in row)
                    if not PN_PATTERN.search(row_text):
                        continue
                    record = {}
                    for i, cell in enumerate(row):
                        field = header_map.get(i)
                        if field:
                            record[field] = (cell or "").strip().replace("\n", " ")
                    if record.get("part_no"):
                        # qty may come through as text -- coerce to int where possible
                        if "qty" in record:
                            m = re.search(r"\d+", record["qty"])
                            record["qty"] = int(m.group()) if m else record["qty"]
                        rows_out.append(record)
    # dedupe: some catalogues repeat each part in a per-item detail table
    # with a DIFFERENT shape (e.g. "Category" instead of a real description) --
    # keep the first row per part_no that has a real (non-generic) description
    GENERIC_DESC_WORDS = {"category", "sub-asm", "material", "qty", "envelope"}
    deduped = {}
    for r in rows_out:
        pn = r["part_no"]
        desc_ok = r.get("description", "").strip().lower() not in GENERIC_DESC_WORDS
        has_qty = isinstance(r.get("qty"), int)
        if not desc_ok or not has_qty:
            continue  # drop junk rows outright -- not a real BOM line
        if pn not in deduped:
            deduped[pn] = r
    return list(deduped.values())

if __name__ == "__main__":
    pdf_path = sys.argv[1] if len(sys.argv) > 1 else "IPC-GBX-450E_parts_catalogue.pdf"
    out_path = sys.argv[2] if len(sys.argv) > 2 else "catalog_extracted.json"
    bom = extract_bom(pdf_path)
    with open(out_path, "w") as f:
        json.dump(bom, f, indent=2)
    print(f"Extracted {len(bom)} BOM rows from {pdf_path} -> {out_path}")
    for r in bom[:5]:
        print(" ", r)
