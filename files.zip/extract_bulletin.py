"""
Generic service-bulletin parser. Reads ANY markdown file with pipe-tables
and extracts them structurally -- doesn't assume column names or how many
correction tables exist. Then applies two generic correction patterns that
service bulletins commonly use:
  1. A table with a "Was" and "Is" column -> textual/numeric correction,
     matched to a part number or step ref found in another column of the
     same row (via the same generic PN_PATTERN used in extract_catalog.py).
  2. A table with a column whose header contains "torque" -> torque spec
     per fastener, matched by part number or description substring.
"""
import re
import json
import sys

PN_PATTERN = re.compile(r"\b[A-Z]{2,6}-[A-Z0-9]{1,8}-[A-Z0-9]{1,6}(?:-[A-Z0-9]{1,4})?\b")
STEP_ID_PATTERN = re.compile(r"\b\d{1,3}-\d{1,3}\b")  # e.g. "20-30", generic procedure-step id

def parse_markdown_tables(md_text):
    """Return list of tables, each a list of dict rows keyed by header text."""
    tables = []
    lines = md_text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith("|") and i + 1 < len(lines) and re.match(r"^\|?[\s:|-]+\|?$", lines[i+1].strip()):
            headers = [h.strip() for h in line.strip("|").split("|")]
            rows = []
            j = i + 2
            while j < len(lines) and lines[j].strip().startswith("|"):
                cells = [c.strip() for c in lines[j].strip("|").split("|")]
                if len(cells) == len(headers):
                    rows.append(dict(zip(headers, cells)))
                j += 1
            tables.append(rows)
            i = j
        else:
            i += 1
    return tables

def extract_corrections(md_path):
    text = open(md_path, encoding="utf-8").read()
    tables = parse_markdown_tables(text)

    part_corrections = {}   # pn -> list of {field, was, is}
    step_corrections = {}   # step_id -> list of {field, was, is}
    torque_specs = {}       # pn -> torque string

    for table in tables:
        if not table:
            continue
        headers = set(table[0].keys())
        has_was_is = any("was" in h.lower() for h in headers) and any(h.lower() == "is" or h.lower().startswith("is") for h in headers)
        has_torque = any("torque" in h.lower() for h in headers)
        has_fastener_col = any("fastener" in h.lower() for h in headers)

        if has_torque and has_fastener_col:
            fastener_key = next(h for h in headers if "fastener" in h.lower())
            torque_key = next(h for h in headers if "torque" in h.lower())
            for row in table:
                pn_match = PN_PATTERN.search(row.get(fastener_key, ""))
                if pn_match:
                    torque_specs[pn_match.group()] = row.get(torque_key, "").strip()
            continue

        if has_was_is:
            was_key = next(h for h in headers if "was" in h.lower())
            is_key = next(h for h in headers if h.lower() == "is" or h.lower().startswith("is"))
            for row in table:
                row_text = " ".join(row.values())
                pn_matches = PN_PATTERN.findall(row_text)
                step_match = STEP_ID_PATTERN.search(row_text)
                field = next((row[h] for h in headers if h.lower() in ("field", "ref", "reference")), None)
                correction = {
                    "field": field,
                    "was": row.get(was_key, "").strip(),
                    "is": row.get(is_key, "").strip(),
                }
                if pn_matches:
                    for pn in pn_matches:
                        part_corrections.setdefault(pn, []).append(correction)
                elif step_match:
                    step_corrections.setdefault(step_match.group(), []).append(correction)

    return {
        "part_corrections": part_corrections,
        "step_corrections": step_corrections,
        "torque_specs": torque_specs,
    }

if __name__ == "__main__":
    md_path = sys.argv[1] if len(sys.argv) > 1 else "service_bulletin_SB-2019-04.md"
    out_path = sys.argv[2] if len(sys.argv) > 2 else "bulletin_extracted.json"
    result = extract_corrections(md_path)
    json.dump(result, open(out_path, "w"), indent=2)
    print(f"Part corrections found: {list(result['part_corrections'].keys())}")
    print(f"Step corrections found: {list(result['step_corrections'].keys())}")
    print(f"Torque specs found: {result['torque_specs']}")
